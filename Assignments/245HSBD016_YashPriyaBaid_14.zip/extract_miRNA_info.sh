#!/bin/bash

read -p "Enter CSV filename: " file

# Find line numbers where each table starts in the file
# 'grep -n' prints the line number and text (like 27:provisional id)
# 'cut -d: -f1' extracts only the line number
novel_start=$(grep -n "provisional id" "$file" | cut -d: -f1)
known_start=$(grep -n "tag id" "$file" | cut -d: -f1)

# Count total number of novel miRNAs (predicted by miRDeep2).
# NR>s && NR<e - select lines between novel_start and known_start.
# Exclude empty lines (^$) and header lines ("provisional id").
novel_total=$(awk -v s="$novel_start" -v e="$known_start" '
NR>s && NR<e && $0 ~ /^chr/ {count++}
END{print count}' "$file")

# Count how many novel miRNAs have significant p-values ("yes")
novel_yes=$(awk -v s="$novel_start" -v e="$known_start" '
NR>s && NR<e && $0 ~ /yes/ {yes++}
END{print yes+0}' "$file")

# Count how many novel miRNAs are non-significant ("no")
novel_no=$(awk -v s="$novel_start" -v e="$known_start" '
NR>s && NR<e && $0 ~ /no/ {no++}
END{print no+0}' "$file")

# Count total number of known (mature) miRNAs.
# Starts after the "tag id" header line till end of file.
# Exclude empty and header lines.
known_total=$(awk -v s="$known_start" '
NR>s && $0 !~ /^$/ && $0 !~ /tag id/ {count++}
END{print count}' "$file")

# Count significant known miRNAs (p-value marked "yes")
known_yes=$(awk -v s="$known_start" '
NR>s && $0 ~ /yes/ {yes++}
END{print yes+0}' "$file")

# Count non-significant known miRNAs (p-value marked "no")
known_no=$(awk -v s="$known_start" '
NR>s && $0 ~ /no/ {no++}
END{print no+0}' "$file")

echo "=== Novel miRNAs (predicted) ==="
echo "Total: $novel_total"
echo "Significant (yes): $novel_yes"
echo "Non-significant (no): $novel_no"
echo "=== Known miRNAs (mature miRBase) ==="
echo "Total: $known_total"
echo "Significant (yes): $known_yes"
echo "Non-significant (no): $known_no"
