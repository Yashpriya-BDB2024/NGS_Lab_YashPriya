#!/bin/bash
# STAR alignment automation for multiple SRR files

# Define paths
TRIM_DIR="$PATH/4_Trim"
INDEX_DIR="$PATH/6_STAR/1_index"
ALIGN_DIR="$PATH/6_STAR/2_alignment"

# Make sure alignment directory exists
mkdir -p "$ALIGN_DIR"
cd "$ALIGN_DIR" || exit

# List of SRR sample IDs
SAMPLES=("SRR15276765" "SRR15276766" "SRR15276767" "SRR15276771" "SRR15276773" "SRR15276774")

for SAMPLE in "${SAMPLES[@]}"; do
    echo "🔹 Running STAR alignment for $SAMPLE..."

    STAR --runMode alignReads \
         --genomeDir "$INDEX_DIR" \
         --readFilesIn "$TRIM_DIR/${SAMPLE}_1_val_1.fq.gz" "$TRIM_DIR/${SAMPLE}_2_val_2.fq.gz" \
         --readFilesCommand gunzip -c \
         --outFileNamePrefix "${SAMPLE}_" \
         --runThreadN 2 \
         --outSAMtype BAM SortedByCoordinate

    # Check if BAM file was created
    if [ -f "${SAMPLE}_Aligned.sortedByCoord.out.bam" ]; then
        echo "✅ Alignment successful for $SAMPLE"
    else
        echo "❌ Alignment failed for $SAMPLE"
    fi
done

echo "🎯 All STAR alignments finished."
