#!/bin/bash
# hisat2_alignment.sh

#JUST CHANGE THE SRR SAMPLE NAMES WHEREVER!

# Base path to your project
BASE="/home/ibab/NGS/rna_seq"

# Reference index prefix (do NOT include .ht2 extensions)
INDEX="$BASE/5_HiSAT2/1_Index/Pfalciparum.genome"

# Path to trimmed FASTQ files
TRIM_DIR="$BASE/4_Trim"

# Output directory for SAM files
OUT_DIR="$BASE/5_HiSAT2/2_alignment"

# Sample IDs
SAMPLES=("SRR15276765" "SRR15276766" "SRR15276767" "SRR15276771" "SRR15276773" "SRR15276774")

# Make sure output directory exists
mkdir -p "$OUT_DIR"

# Run HiSAT2 for each sample
for SAMPLE in "${SAMPLES[@]}"; do
    echo "==============================================="
    echo "Running HiSAT2 for $SAMPLE ..."
    echo "==============================================="

    READ1="$TRIM_DIR/${SAMPLE}_1_val_1.fq.gz"
    READ2="$TRIM_DIR/${SAMPLE}_2_val_2.fq.gz"
    SAM_OUT="$OUT_DIR/${SAMPLE}.sam"
    BAM_OUT="$OUT_DIR/${SAMPLE}.bam"

    # Check if FASTQ files exist
    if [[ ! -f "$READ1" || ! -f "$READ2" ]]; then
        echo "❌ Error: FASTQ files for $SAMPLE not found, skipping..."
        continue
    fi

    # Run HiSAT2
    hisat2 -x "$INDEX" -1 "$READ1" -2 "$READ2" -S "$SAM_OUT"

    if [[ $? -eq 0 ]]; then
        echo "✅ HiSAT2 finished successfully for $SAMPLE"
    else
        echo "❌ HiSAT2 failed for $SAMPLE, skipping SAM→BAM conversion"
        continue
    fi

    # Convert SAM → BAM
    samtools view -bS "$SAM_OUT" > "$BAM_OUT"

    if [[ $? -eq 0 ]]; then
        echo "✅ Converted $SAM_OUT to $BAM_OUT"
    else
        echo "❌ SAM to BAM conversion failed for $SAMPLE"
    fi
done

echo "🎉 All alignments completed!"
