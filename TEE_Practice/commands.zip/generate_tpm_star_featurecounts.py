import pandas as pd 
 
# Load the data 
file_path = 'raw_read_for_tpm.txt'  # Update the file path if needed 
data = pd.read_csv(file_path, sep='\t') 
 
# Ensure the data is loaded correctly 
print("Data loaded successfully. Here are the first few rows:") 
print(data.head()) 
 
# Identify count columns (exclude 'Geneid' and 'Length') 
rpk_cols = [col for col in data.columns if col not in ['Geneid', 'Length']] 
 
# Calculate RPK for each gene and each sample 
for col in rpk_cols: 
    data['RPK_{}'.format(col)] = data[col] / (data['Length'] / 1000)  # divide by length in kb 
 
# Calculate TPM for each gene and each sample 
for col in rpk_cols: 
    rpk_col = 'RPK_{}'.format(col) 
    tpm_col = 'TPM_{}'.format(col) 
    total_rpk = data[rpk_col].sum() 
    data[tpm_col] = (data[rpk_col] / total_rpk) * 1e6 
 
# Select columns to save (Geneid, Length, TPM values) 
tpm_cols = ['Geneid', 'Length'] + ['TPM_{}'.format(col) for col in rpk_cols] 
tpm_data = data[tpm_cols] 
 
# Display first few TPM values to check 
print("Calculated TPM values:") 
print(tpm_data.head()) 
 
# Save the TPM table to a new file 
output_file_path = 'tpm_results.txt' 
tpm_data.to_csv(output_file_path, sep='\t', index=False) 
 
print(f"✅ TPM calculation complete! Output saved to '{output_file_path}'") 
