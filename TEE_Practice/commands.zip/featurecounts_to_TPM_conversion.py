import pandas as pd

# Load merged raw reads
data = pd.read_csv('merged_featurecounts.txt', sep='\t')

# Load one featureCounts file to get lengths
fc_file = 'SRR15276765.txt'
fc_df = pd.read_csv(fc_file, sep='\t', comment='#', skiprows=1)

# Keep only Geneid and Length
length_df = fc_df[['Geneid', 'Length']]

# Merge lengths into merged counts using Geneid
data = pd.merge(length_df, data, on='Geneid')

# Calculate RPK and TPM
rpk_cols = [col for col in data.columns if col not in ['Geneid', 'Length']]

for col in rpk_cols:
    data['RPK_{}'.format(col)] = data[col] / (data['Length'] / 1000)

for col in rpk_cols:
    rpk_col = 'RPK_{}'.format(col)
    tpm_col = 'TPM_{}'.format(col)
    total_rpk = data[rpk_col].sum()
    data[tpm_col] = (data[rpk_col] / total_rpk) * 1e6

# Select columns to save (Geneid, Length, TPM values)
tpm_cols = ['Geneid', 'Length'] + ['TPM_{}'.format(col) for col in rpk_cols]
tpm_data = data[tpm_cols]

# -----------------------------
# Filter only Plasmodium genes starting with 'PF3D7_'
tpm_data = tpm_data[tpm_data['Geneid'].str.startswith('PF3D7_')]
# -----------------------------

# Save filtered TPM table
tpm_data.to_csv('tpm_results_filtered.txt', sep='\t', index=False)

print("✅ TPM calculation complete! Filtered file saved as 'tpm_results_filtered.txt'")
