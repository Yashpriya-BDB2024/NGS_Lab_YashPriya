#!/bin/bash
# Run Qualimap BAMQC for multiple BAM files

ALIGN_DIR="$PATH/6_STAR/2_alignment"
OUT_DIR="$PATH/7_Qualimap"

# Make sure output directory exists
mkdir -p "$OUT_DIR"
cd "$ALIGN_DIR" || exit

# List of SRR sample IDs
SAMPLES=("SRR15276765" "SRR15276766" "SRR15276767" "SRR15276771" "SRR15276773" "SRR15276774")

for SAMPLE in "${SAMPLES[@]}"; do
    BAM_FILE="${SAMPLE}_Aligned.sortedByCoord.out.bam"
    OUT_FILE="$OUT_DIR/${SAMPLE}_bamqc.pdf"

    echo "🔹 Running Qualimap BAMQC for $SAMPLE..."

    qualimap bamqc \
        -bam "$BAM_FILE" \
        -outfile "${SAMPLE}_bamqc" \
        -outformat pdf \
        -outdir "$OUT_DIR"

    # Check if PDF was created
    if [ -f "$OUT_FILE" ]; then
        echo "✅ Qualimap report created: $OUT_FILE"
    else
        echo "❌ Qualimap failed for $SAMPLE"
    fi
done

echo "🎯 All Qualimap BAMQC reports finished."
