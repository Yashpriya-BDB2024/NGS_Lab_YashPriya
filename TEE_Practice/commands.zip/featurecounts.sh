#!/bin/bash
# Automate featureCounts for multiple BAM files

ALIGN_DIR="$PATH/5_HiSAT2/2_alignment"   # folder where your BAMs are
REF_GTF="$PATH/2_Reference/Pfalci.genome.gtf"
OUT_DIR="$PATH/8_featureCounts"

# Make sure output folder exists
mkdir -p "$OUT_DIR"
cd "$ALIGN_DIR" || exit

# List of SRR IDs
SAMPLES=("SRR15276765" "SRR15276766" "SRR15276767" "SRR15276771" "SRR15276773" "SRR15276774")

for SAMPLE in "${SAMPLES[@]}"; do
    BAM_FILE="${SAMPLE}_sorted.bam"
    OUT_FILE="$OUT_DIR/${SAMPLE}_counts.txt"

    echo "🔹 Running featureCounts for $SAMPLE..."

    featureCounts \
        -p \
        -t exon \
        -g gene_id \
        -a "$REF_GTF" \
        -o "$OUT_FILE" \
        "$ALIGN_DIR/$BAM_FILE"

    # Check if output file exists
    if [ -f "$OUT_FILE" ]; then
        echo "✅ featureCounts finished: $OUT_FILE"
    else
        echo "❌ featureCounts failed for $SAMPLE"
    fi
done

echo "🎯 All featureCounts jobs finished!"
