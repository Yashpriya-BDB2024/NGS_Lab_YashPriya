import os
import pandas as pd
def load_featurecounts(filepath):
    """
    Load a featureCounts result file and return a DataFrame with Geneid and counts.
    """
    df = pd.read_csv(filepath, sep='\t', comment='#', header=0, dtype=str)
    if 'Geneid' not in df.columns:
        raise ValueError(f"'Geneid' column not found in {filepath}")
    # Use last column as counts
    count_column = df.columns[-1]
    sample_id = os.path.splitext(os.path.basename(filepath))[0]
    # Keep only Geneid + sample
    subset = df[['Geneid', count_column]].copy()
    subset = subset.rename(columns={count_column: sample_id})
    subset[sample_id] = pd.to_numeric(subset[sample_id], errors='coerce').fillna(0).astype(int)
    return subset
# directory containing featureCounts files
input_dir = "/home/ibab/NGS/rna_seq/6_STAR/4_featurecounts" #path
# collect candidate files
files = [
    os.path.join(input_dir, fname)
    for fname in os.listdir(input_dir)
    if fname.endswith(".txt") and os.path.isfile(os.path.join(input_dir, fname))
]
files.sort()
# load all into list
tables = [load_featurecounts(f) for f in files]
# merge step by step on Geneid
combined = tables[0]
for t in tables[1:]:
    combined = pd.merge(combined, t, on='Geneid', how='outer')
# fill NA with 0
for col in combined.columns:
    if col != 'Geneid':
        combined[col] = pd.to_numeric(combined[col], errors='coerce').fillna(0).astype(int)
# save result
output_file = os.path.join(input_dir, "merged_featurecounts.txt")
combined.to_csv(output_file, sep='\t', index=False)
# combined.to_csv(output_file.replace(".csv", ".txt"), sep='\t', index=False)


print(f"Merged featureCounts table saved to {output_file}")
