#!/bin/bash

# Define the list of SRR IDs
SRR_LIST=("SRR15276765" "SRR15276766" "SRR15276767" "SRR15276771" "SRR15276773" "SRR15276774")

# Paths
ALIGN_DIR="../2_alignment"
REF_GTF="../2_reference/Pfalciparum.genome.gtf"
OUT_DIR="./"   # Current directory for output files

# Loop through each SRR ID
for SRR in "${SRR_LIST[@]}"
do
    echo "Processing $SRR..."
    
    htseq-count "${ALIGN_DIR}/${SRR}Aligned.sortedByCoord.out.bam" \
                "$REF_GTF" \
                --idattr gene_id \
                -t exon \
                -f bam \
                > "${OUT_DIR}/${SRR}_htseq.txt"
    
    echo "$SRR done!"
done

echo "All samples processed."
