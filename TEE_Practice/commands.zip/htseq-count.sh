#!/bin/bash

# Path to your base directory
PATH_BASE="/home/ibab/NGS/rna_seq"   # <-- change to your correct project directory

# List of SRR IDs
SAMPLES=("SRR15276765" "SRR15276766" "SRR15276767" "SRR15276771" "SRR15276773" "SRR15276774")

# Loop over each sample and run htseq-count
for SAMPLE in "${SAMPLES[@]}"; do
    echo "Running htseq-count for $SAMPLE ..."
    htseq-count \
        "$PATH_BASE/5_Hisat2/2_Alignment/${SAMPLE}_sorted.bam" \
        "$PATH_BASE/1_Reference/Pfalciparum.genome.gtf" \
        --idattr gene_id -t exon -f bam \
        > "${SAMPLE}_htseq.txt"

    if [[ $? -eq 0 ]]; then
        echo "✅ Finished $SAMPLE"
    else
        echo "❌ Error in $SAMPLE"
    fi
done

echo "All htseq-count jobs done."
