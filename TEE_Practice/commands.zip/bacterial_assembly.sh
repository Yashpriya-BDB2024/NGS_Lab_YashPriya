#!/bin/bash

set -euo pipefail
IFS=$'\n\t'

# $#: number of arguments supplied to the script
if [[ $# -eq 1 ]]; then
    mode="single"          # single-end run
    r1_input=$1            # path to single FASTQ file
elif [[ $# -eq 2 ]]; then
    mode="paired"          # paired-end run
    r1_input=$1            # path to read1 FASTQ
    r2_input=$2            # path to read2 FASTQ
else
    # if arguments are not 1 or 2, show usage and exit
    echo "Usage:"
    echo "  Single-end : bash $0 <reads.fq.gz>"
    echo "  Paired-end : bash $0 <R1.fq.gz> <R2.fq.gz>"
    exit 1
fi

# Check that each input file actually exists
for f in "$@"; do
    [[ -f "$f" ]] || { echo "ERROR: File $f not found"; exit 1; }
done

base_dir=$(pwd)                        # current working directory
assembly_dir="$base_dir/genome_assembly"
fastqc_dir="$assembly_dir/fastqc"      # FastQC output folder
spades_dir="$assembly_dir/spades"      # SPAdes output folder
quast_dir="$assembly_dir/quast"        # QUAST output folder

echo "[1/8] Creating directories..."
mkdir -p "$fastqc_dir" "$spades_dir" "$quast_dir"

# Ask user whether to run FastQC
read -p "Run FastQC on the trimmed reads? (y/n): " run_fq
# convert input to lower case for consistent checking
run_fq=$(echo "$run_fq" | tr '[:upper:]' '[:lower:]')

if [[ "$run_fq" == "y" || "$run_fq" == "yes" ]]; then
    echo "[2/8] Running FastQC..."
    # run FastQC on single or paired inputs and save reports to fastqc_dir
    if [[ "$mode" == "paired" ]]; then
        fastqc -o "$fastqc_dir" "$r1_input" "$r2_input"
    else
        fastqc -o "$fastqc_dir" "$r1_input"
    fi
else
    echo "[2/8] Skipping FastQC."
fi

# ---------- SPAdes Mode Selection ----------
echo "Choose SPAdes run mode:"
echo "1: Default parameters"
echo "2: Custom parameters"
read -p "Enter choice (1/2): " spades_mode

# If custom mode is selected, ask for extra parameters
custom_opts=""    # empty by default
if [[ "$spades_mode" == "2" ]]; then
    read -p "Enter number of threads (e.g. 8): " threads
    read -p "Enter memory in GB (e.g. 32): " memory
    read -p "Enter coverage cutoff (number or auto): " covcut
    read -p "Use --careful? (y/n): " careful
    # add --careful flag only if user answers yes
    [[ "$careful" =~ ^[Yy]$ ]] && careful_flag="--careful" || careful_flag=""
    # build the custom options string
    custom_opts="-t $threads -m $memory --cov-cutoff $covcut $careful_flag --phred-offset 33"
    echo "[3/8] SPAdes custom options: $custom_opts"
else
    echo "[3/8] SPAdes will run with default parameters."
fi

# ---------- SPAdes Assembly ----------
echo "[4/8] Running SPAdes ($mode-end)..."
cd "$spades_dir"
if [[ "$mode" == "paired" ]]; then
    # paired-end assembly
    spades.py -1 "$r1_input" -2 "$r2_input" -o . $custom_opts
else
    # single-end assembly
    spades.py -s "$r1_input" -o . $custom_opts
fi

# store paths to expected output files
contigs="$spades_dir/contigs.fasta"
scaffolds="$spades_dir/scaffolds.fasta"

# verify that contigs.fasta exists (basic success check)
[[ -f "$contigs" ]] || { echo "ERROR: contigs.fasta not generated"; exit 1; }

# count the number of sequences in contigs and scaffolds
echo "[INFO] Contigs count : $(grep -c '^>' "$contigs")"
if [[ -f "$scaffolds" ]]; then
    echo "[INFO] Scaffolds count : $(grep -c '^>' "$scaffolds")"
else
    echo "[INFO] scaffolds.fasta not found (may be normal)."
fi

# ---------- QUAST Evaluation ----------
echo "[5/8] Running QUAST on contigs..."
cd "$quast_dir"
python3 $(which quast.py) -o quast_contig_out "$contigs"

# run QUAST on scaffolds only if the file exists
if [[ -f "$scaffolds" ]]; then
    echo "[6/8] Running QUAST on scaffolds..."
    python3 $(which quast.py) -o quast_scaffold_out "$scaffolds"
else
    echo "[6/8] Skipping scaffolds QUAST."
fi

# ---------- Completion ----------
echo "[7/8] Workflow completed successfully!"
echo "Results Summary:"
if [[ "$run_fq" == "y" || "$run_fq" == "yes" ]]; then
    echo "  FastQC reports -> $fastqc_dir"
else
    echo "  FastQC reports -> (not generated)"
fi
echo "  SPAdes output  -> $spades_dir"
echo "  QUAST reports  -> $quast_dir/quast_*_out"
echo "[8/8] Done."

