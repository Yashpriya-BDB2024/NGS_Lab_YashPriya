#!/bin/bash

# Usage: ./gene_length.sh input.gtf output.txt
# Example: ./gene_length.sh GCF_000005845.2_ASM584v2_genomic.gtf gene_lengths.txt

INPUT="$1"
OUTPUT="$2"

awk '$3=="gene"{start=$4;end=$5;length=(end-start+1)/1000;match($9,/gene_id "([^"]+)"/,arr);if(arr[1]!=""){print arr[1],length}}' "$INPUT" > "$OUTPUT"

echo "Gene lengths saved to $OUTPUT"

