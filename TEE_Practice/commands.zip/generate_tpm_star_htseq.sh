#!/bin/bash

GTF="../../2_reference/Pfalciparum.genome.gtf"
OUTPUT="raw_read_for_tpm.txt"

# Sample files
SAMPLES=(SRR15276765_htseq.txt SRR15276766_htseq.txt SRR15276767_htseq.txt SRR15276771_htseq.txt SRR15276773_htseq.txt SRR15276774_htseq.txt)

# 1️⃣ Read counts into array
declare -A counts
declare -a genes

# Read counts from the first sample to get the gene order
while IFS=$'\t' read -r gene c1; do
    [[ $gene == "Geneid" || $gene != PF3D7_* ]] && continue
    genes+=("$gene")
    counts[$gene,0]=$c1
done < "${SAMPLES[0]}"

# Read the other samples
for i in {1..5}; do
    idx=$i
    while IFS=$'\t' read -r gene c; do
        [[ $gene == "Geneid" || $gene != PF3D7_* ]] && continue
        counts[$gene,$idx]=$c
    done < "${SAMPLES[$i]}"
done

# 2️⃣ Compute gene lengths from GTF
declare -A lengths
while IFS=$'\t' read -r chr src type start end score strand frame attr; do
    [[ $type != "exon" ]] && continue
    if [[ $attr =~ gene_id\ \"([^\"]+)\" ]]; then
        gene="${BASH_REMATCH[1]}"
        # Sum exon lengths
        len=$((end-start+1))
        (( lengths[$gene]+=$len ))
    fi
done < "$GTF"

# 3️⃣ Write TPM-ready file with lengths in kb
{
    echo -e "Gene_ID\tGene_length\tSRR15276765\tSRR15276766\tSRR15276767\tSRR15276771\tSRR15276773\tSRR15276774"
    for gene in "${genes[@]}"; do
        # Convert length to kb
        glength=$(awk "BEGIN{print ${lengths[$gene]:-0}/1000}")
        echo -e "$gene\t$glength\t${counts[$gene,0]}\t${counts[$gene,1]}\t${counts[$gene,2]}\t${counts[$gene,3]}\t${counts[$gene,4]}\t${counts[$gene,5]}"
    done
} > "$OUTPUT"

echo "✅ TPM-ready file created: $OUTPUT"
head -n 10 "$OUTPUT"
