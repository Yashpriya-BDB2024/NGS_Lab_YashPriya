#!/bin/bash

set -euo pipefail                 # fail on error, unset var or pipe failure
IFS=$'\n\t'                       # safe IFS

err_exit() {
    echo "ERROR: $1" >&2
    exit 1
}

# ---------- helper: find executable (prefers .py then plain) ----------
# returns full path in global var exec_path or empty if not found
find_exec() {
    local name="$1"
    exec_path=""
    # try exact name (may be ragtag.py, ragtag, ragtag_correct.py, quast.py, quast)
    if command -v "$name" >/dev/null 2>&1; then
        exec_path="$(command -v "$name")"
        return 0
    fi
    # if .py variant exists
    if command -v "${name}.py" >/dev/null 2>&1; then
        exec_path="$(command -v "${name}.py")"
        return 0
    fi
    # not found
    exec_path=""
    return 1
}

# ---------- 0. Ask user for input file paths ----------
read -p "Enter path to reference genome (e.g. GCF_xxx.fna or GCF_xxx.fna.gz): " ref_input
read -p "Enter path to draft genome (e.g. GCA_xxx.fna or GCA_xxx.fna.gz): " draft_input

# verify files exist
[[ -f "$ref_input" ]] || err_exit "Reference file not found: $ref_input"
[[ -f "$draft_input" ]] || err_exit "Draft file not found: $draft_input"

# ---------- 1. Ask which QUAST runs to perform ----------
echo "Do you want to run QUAST before improvement? (pre-improvement) (y/n)"
read -r run_quast_pre
run_quast_pre=$(echo "$run_quast_pre" | tr '[:upper:]' '[:lower:]')

echo "Do you want to run QUAST after improvement? (post-improvement) (y/n)"
read -r run_quast_post
run_quast_post=$(echo "$run_quast_post" | tr '[:upper:]' '[:lower:]')

echo "Do you want to run comparative QUAST (compare pre vs post)? (y/n)"
read -r run_quast_comp
run_quast_comp=$(echo "$run_quast_comp" | tr '[:upper:]' '[:lower:]')

# ---------- 2. Prepare workspace directories ----------
work_dir="$(pwd)/Genome_improvement"           # base workspace (created in current dir)
pre_quast_dir="$work_dir/quast_pre"            # pre improvement quast results
post_quast_dir="$work_dir/quast_post"          # post improvement quast results
corr_dir="$work_dir/ragtag_correction"         # ragtag correction output
scaf_dir="$work_dir/ragtag_scaffold"           # ragtag scaffold output
tmp_dir="$work_dir/tmp_uncompressed"           # temporary uncompressed copies

mkdir -p "$pre_quast_dir" "$post_quast_dir" "$corr_dir" "$scaf_dir" "$tmp_dir"

echo "[0] workspace created at: $work_dir"

# ---------- 3. Locate quast executable ----------
# prefer quast.py if present (then call with python3), else quast
if find_exec "quast.py"; then
    quast_exec="$exec_path"
    quast_call="python3 \"$quast_exec\""   # call via python3 when it's a .py
elif find_exec "quast"; then
    quast_exec="$exec_path"
    quast_call="\"$quast_exec\""           # call directly
else
    quast_exec=""
    quast_call=""
    echo "WARNING: quast not found in PATH. QUAST steps will fail if you try to run them."
fi

# ---------- 4. Locate ragtag executables ----------
# ragtag modern uses ragtag.py with subcommands; older installs provide ragtag_correct.py & ragtag_scaffold.py
ragtag_mode="none"
if find_exec "ragtag.py"; then
    ragtag_exec="$exec_path"
    ragtag_mode="ragtag_py"    # will call: python3 $ragtag_exec correct/scaffold ...
elif find_exec "ragtag"; then
    ragtag_exec="$exec_path"
    ragtag_mode="ragtag"       # will call: ragtag correct/scaffold ...
elif find_exec "ragtag_correct.py" && find_exec "ragtag_scaffold.py"; then
    ragtag_correct_exec="$exec_path"
    # ensure both found: find the other explicitly
    find_exec "ragtag_scaffold.py"
    ragtag_scaffold_exec="$exec_path"
    ragtag_mode="separate_scripts"
else
    ragtag_mode="notfound"
fi

if [[ "$ragtag_mode" == "notfound" ]]; then
    err_exit "RagTag executables not found (ragtag.py or ragtag_correct.py/ragtag_scaffold.py). Install RagTag or add to PATH."
fi

echo "[0] found ragtag mode: $ragtag_mode"

# ---------- 5. Uncompress reference & draft locally if needed ----------
# We create local uncompressed copies in tmp_dir so downstream tools (bwa, ragtag) can work reliably.
make_uncompressed_copy() {
    local input="$1"
    local outdir="$2"
    local outpath

    local base
    base="$(basename "$input")"
    # remove .gz if present
    if [[ "$base" == *.gz ]]; then
        base_no_gz="${base%.gz}"
    else
        base_no_gz="$base"
    fi

    outpath="$outdir/$base_no_gz"

    # if the outpath already exists and is non-empty, reuse it
    if [[ -s "$outpath" ]]; then
        echo "Using existing uncompressed copy: $outpath"
        echo "$outpath"
        return 0
    fi

    # produce uncompressed copy
    if [[ "$input" == *.gz ]]; then
        echo "Uncompressing $input -> $outpath"
        gunzip -c "$input" > "$outpath"
    else
        echo "Copying $input -> $outpath"
        cp "$input" "$outpath"
    fi
    echo "$outpath"
    return 0
}

ref_fa="$(make_uncompressed_copy "$ref_input" "$tmp_dir")"    # path to uncompressed ref
draft_fa="$(make_uncompressed_copy "$draft_input" "$tmp_dir")" # path to uncompressed draft

# ---------- 6. Optionally run QUAST pre-improvement ----------
if [[ "$run_quast_pre" == "y" || "$run_quast_pre" == "yes" ]]; then
    [[ -n "$quast_call" ]] || err_exit "QUAST executable not found; cannot run pre-QUAST."
    echo "[1/6] Running QUAST (pre-improvement)..."
    # QUAST can take gz or uncompressed; we use uncompressed to be consistent
    eval "$quast_call -o \"$pre_quast_dir\" \"$ref_fa\" \"$draft_fa\""
    echo "✓ QUAST pre-improvement done. Report: $pre_quast_dir/report.txt"
else
    echo "[1/6] Skipping pre-improvement QUAST (user choice)."
fi

# ---------- 7. BWA index: check presence and run only if missing ----------
# bwa index creates files with extensions .amb .ann .bwt .pac .sa
check_bwa_index() {
    local fasta="$1"
    local prefix="$fasta"
    local exts=(amb ann bwt pac sa)
    for e in "${exts[@]}"; do
        if [[ ! -f "${prefix}.${e}" ]]; then
            return 1    # missing one file -> index not present
        fi
    done
    return 0    # all present
}

echo "[2/6] Checking BWA index for reference..."
if check_bwa_index "$ref_fa"; then
    echo "✓ BWA index already present for $ref_fa, skipping indexing."
else
    echo "Index files missing. Running: bwa index $ref_fa"
    bwa index "$ref_fa" || err_exit "bwa index failed for $ref_fa"
    echo "✓ BWA indexing completed."
fi

# ---------- 8. RagTag CORRECTION (uses reference + draft) ----------
echo "[3/6] Running RagTag correction..."
# choose correct call depending on ragtag mode
if [[ "$ragtag_mode" == "ragtag_py" ]]; then
    echo "Calling: python3 $ragtag_exec correct -o $corr_dir $ref_fa $draft_fa"
    python3 "$ragtag_exec" correct -o "$corr_dir" "$ref_fa" "$draft_fa"
elif [[ "$ragtag_mode" == "ragtag" ]]; then
    echo "Calling: $ragtag_exec correct -o $corr_dir $ref_fa $draft_fa"
    "$ragtag_exec" correct -o "$corr_dir" "$ref_fa" "$draft_fa"
elif [[ "$ragtag_mode" == "separate_scripts" ]]; then
    echo "Calling: $ragtag_correct_exec $ref_fa $draft_fa -o $corr_dir"
    "$ragtag_correct_exec" "$ref_fa" "$draft_fa" -o "$corr_dir"
else
    err_exit "Unsupported ragtag mode: $ragtag_mode"
fi

# locate corrected fasta (commonly ragtag.correct.fasta or ragtag.corrected.fasta)
corrected_fa=""
if [[ -f "$corr_dir/ragtag.correct.fasta" ]]; then
    corrected_fa="$corr_dir/ragtag.correct.fasta"
elif [[ -f "$corr_dir/ragtag.corrected.fasta" ]]; then
    corrected_fa="$corr_dir/ragtag.corrected.fasta"
elif [[ -f "$corr_dir/ragtag.correct.fna" ]]; then
    corrected_fa="$corr_dir/ragtag.correct.fna"
fi

[[ -n "$corrected_fa" && -s "$corrected_fa" ]] || err_exit "RagTag correction did not produce a non-empty corrected fasta in $corr_dir"

echo "✓ RagTag correction produced: $corrected_fa"

# ---------- 9. RagTag SCAFFOLD using corrected assembly ----------
echo "[4/6] Running RagTag scaffolding..."
if [[ "$ragtag_mode" == "ragtag_py" ]]; then
    echo "Calling: python3 $ragtag_exec scaffold -o $scaf_dir $ref_fa $corrected_fa"
    python3 "$ragtag_exec" scaffold -o "$scaf_dir" "$ref_fa" "$corrected_fa"
elif [[ "$ragtag_mode" == "ragtag" ]]; then
    echo "Calling: $ragtag_exec scaffold -o $scaf_dir $ref_fa $corrected_fa"
    "$ragtag_exec" scaffold -o "$scaf_dir" "$ref_fa" "$corrected_fa"
elif [[ "$ragtag_mode" == "separate_scripts" ]]; then
    echo "Calling: $ragtag_scaffold_exec $ref_fa $corrected_fa -o $scaf_dir"
    "$ragtag_scaffold_exec" "$ref_fa" "$corrected_fa" -o "$scaf_dir"
fi

scaffold_fa="$scaf_dir/ragtag.scaffolds.fasta"
[[ -s "$scaffold_fa" ]] || { # try alternative names
    if [[ -f "$scaf_dir/scaffolds.fasta" ]]; then
        scaffold_fa="$scaf_dir/scaffolds.fasta"
    elif [[ -f "$scaf_dir/ragtag.scaffold.fasta" ]]; then
        scaffold_fa="$scaf_dir/ragtag.scaffold.fasta"
    fi
}

[[ -s "$scaffold_fa" ]] || err_exit "RagTag scaffolding failed to produce scaffolds fasta in $scaf_dir"

echo "✓ RagTag scaffolding produced: $scaffold_fa"

# ---------- 10. Optionally run QUAST post-improvement ----------
if [[ "$run_quast_post" == "y" || "$run_quast_post" == "yes" ]]; then
    [[ -n "$quast_call" ]] || err_exit "QUAST executable not found; cannot run post-QUAST."
    echo "[5/6] Running QUAST on improved (scaffolded) genome..."
    eval "$quast_call -o \"$post_quast_dir\" \"$scaffold_fa\""
    echo "✓ QUAST post-improvement done. Report: $post_quast_dir/report.txt"
else
    echo "[5/6] Skipping post-improvement QUAST (user choice)."
fi

# ---------- 11. Optionally run comparative QUAST (draft vs scaffold) ----------
if [[ "$run_quast_comp" == "y" || "$run_quast_comp" == "yes" ]]; then
    [[ -n "$quast_call" ]] || err_exit "QUAST executable not found; cannot run comparative QUAST."
    echo "[6/6] Running comparative QUAST (draft vs improved scaffold)..."
    # use pre-created pre_quast_dir if pre quast run earlier; else provide draft and scaffold
    eval "$quast_call -o \"$work_dir/quast_comparative\" \"$draft_fa\" \"$scaffold_fa\""
    echo "✓ Comparative QUAST done. Report: $work_dir/quast_comparative/report.txt"
else
    echo "[6/6] Skipping comparative QUAST (user choice)."
fi

echo "ALL STEPS FINISHED. Results summary:"
echo " - pre-QUAST:  $pre_quast_dir"
echo " - correction: $corr_dir"
echo " - scaffold:   $scaf_dir"
echo " - post-QUAST: $post_quast_dir"
echo " - comparative quast (if run): $work_dir/quast_comparative"
echo "Temporary uncompressed files in: $tmp_dir (you can remove when done)"

exit 0

