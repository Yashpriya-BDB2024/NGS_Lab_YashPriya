# ============================
# limma-voom with PCA, Heatmap, Volcano (single PDF)
# ============================

library(edgeR)
library(limma)
library(ggplot2)
library(pheatmap)

# Load data
counts <- read.table("raw_reads.txt", header=TRUE, row.names=1, sep="\t", check.names=FALSE)
samples <- c("SRR15276765","SRR15276766","SRR15276767","SRR15276771","SRR15276773","SRR15276774")
#counts <- counts[, samples] #changed this line
# Clean up the long sample names to be short and readable
colnames(counts) <- gsub("../2_alignment/", "", colnames(counts))
colnames(counts) <- gsub("_sorted.bam", "", colnames(counts))
# --------------------------
group <- factor(c("Control","Control","Control","Treatment","Treatment","Treatment"),
                levels = c("Control","Treatment"))

# Create DGEList
dge <- DGEList(counts=counts, group=group)
keep <- filterByExpr(dge)
dge <- dge[keep,, keep.lib.sizes=FALSE]
dge <- calcNormFactors(dge)

design <- model.matrix(~ group)
v <- voom(dge, design, plot=FALSE)
fit <- lmFit(v, design)
fit <- eBayes(fit)
res <- topTable(fit, coef=2, number=Inf)
write.csv(res, "limma_results.csv")

# Open a single PDF
pdf("limma_plots.pdf", width=7, height=7)

# --- PCA plot ---
# --- PCA plot with % variance and sample names ---
pca <- prcomp(t(v$E), scale.=TRUE)

# % variance explained
percentVar <- round(100 * (pca$sdev^2 / sum(pca$sdev^2))[1:2], 1)

pca_df <- data.frame(PC1 = pca$x[,1],
                     PC2 = pca$x[,2],
                     condition = group,
                     sample = rownames(pca$x))

p1 <- ggplot(pca_df, aes(PC1, PC2, color=condition, label=sample)) +
  geom_point(size=4) +
  geom_text(vjust=-1, size=3) +   # add sample names
  xlab(paste0("PC1: ", percentVar[1], "%")) +
  ylab(paste0("PC2: ", percentVar[2], "%")) +
  theme_classic() +
  ggtitle("PCA Plot")
print(p1)


# --- Heatmap (PCC) ---
# --- Heatmap (PCC) ---
pcc <- cor(v$E, method="pearson")
annotation_col <- data.frame(condition=group)
rownames(annotation_col) <- colnames(pcc)

pheatmap(pcc,
         annotation_col = annotation_col,
         main = "Sample PCC Heatmap")


# --- Volcano plot ---
res$threshold <- "Not Significant"
res$threshold[res$P.Value < 0.05 & abs(res$logFC) >= 1] <- "Significant (FC & P)"
res$threshold[res$P.Value < 0.05 & abs(res$logFC) < 1] <- "Significant (P only)"
res$threshold[res$P.Value >= 0.05 & abs(res$logFC) >= 1] <- "Significant (FC only)"
res$threshold <- factor(res$threshold, levels=c("Not Significant","Significant (P only)","Significant (FC only)","Significant (FC & P)"))

p2 <- ggplot(res, aes(x=logFC, y=-log10(P.Value), color=threshold)) +
  geom_point(alpha=0.6) +
  scale_color_manual(values=c("grey","blue","green","red")) +
  theme_minimal() +
  xlab("log2 Fold Change") + ylab("-log10 P-value") +
  ggtitle("Volcano Plot")
print(p2)

# Close PDF
dev.off()

cat("✅ limma-voom analysis complete! Results + plots saved in limma_results.csv and limma_plots.pdf\n")

