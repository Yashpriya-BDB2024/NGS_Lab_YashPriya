# ============================
# edgeR with PCA, Heatmap, Volcano (Combined Plot)
# ============================

library(edgeR)
library(ggplot2)
library(pheatmap)
library(grid)
library(cowplot)   # for combining plots

# Load data
counts <- read.table("raw_reads.txt", header=TRUE, row.names=1, sep="\t", check.names=FALSE)
samples <- c("SRR15276765","SRR15276766","SRR15276767",
             "SRR15276771","SRR15276773","SRR15276774")
#counts <- counts[, samples] #changed this line
colnames(counts) <- gsub("../2_alignment/", "", colnames(counts))
colnames(counts) <- gsub("_sorted.bam", "", colnames(counts))
group <- factor(c("Control","Control","Control","Treatment","Treatment","Treatment"),
                levels = c("Control","Treatment"))

# Create DGEList
dge <- DGEList(counts=counts, group=group)
keep <- filterByExpr(dge)
dge <- dge[keep,, keep.lib.sizes=FALSE]
dge <- calcNormFactors(dge)

design <- model.matrix(~ group)
dge <- estimateDisp(dge, design)
fit <- glmFit(dge, design)
lrt <- glmLRT(fit, coef=2)
res <- topTags(lrt, n=Inf)$table
write.csv(res, "edgeR_results.csv")

# ============================
# PCA
# ============================
logCPM <- cpm(dge, log=TRUE, prior.count=1)
pca <- prcomp(t(logCPM))
percentVar <- (pca$sdev^2) / sum(pca$sdev^2) * 100
pca_df <- data.frame(PC1=pca$x[,1], PC2=pca$x[,2],
                     condition=group, sample=colnames(logCPM))

p_pca <- ggplot(pca_df, aes(PC1, PC2, color=condition, label=sample)) +
  geom_point(size=4) +
  geom_text(vjust=-1, size=3) +
  theme_classic() +
  xlab(paste0("PC1: ", round(percentVar[1], 1), "% variance")) +
  ylab(paste0("PC2: ", round(percentVar[2], 1), "% variance")) +
  ggtitle("PCA Plot")

# ============================
# Heatmap (PCC)
# ============================
annotation_col <- data.frame(condition=group)
rownames(annotation_col) <- colnames(logCPM)
pcc <- cor(logCPM, method="pearson")

p_heatmap <- grid.grabExpr(pheatmap(pcc, annotation_col=annotation_col,
                                    main="Pearson Correlation Heatmap"))

# ============================
# Volcano Plot
# ============================
res_df <- as.data.frame(res)
logFC_threshold <- 0.5
PValue_threshold <- 0.05

res_df$category <- "Not Sig"
res_df$category[res_df$PValue < PValue_threshold & res_df$logFC >= logFC_threshold] <- "Up"
res_df$category[res_df$PValue < PValue_threshold & res_df$logFC <= -logFC_threshold] <- "Down"

p_volcano <- ggplot(res_df, aes(x=logFC, y=-log10(PValue), color=category)) +
  geom_point(alpha=0.6) +
  scale_color_manual(values=c("Down"="blue", "Not Sig"="grey", "Up"="red")) +
  theme_classic() +
  xlab("log2 Fold Change") +
  ylab("-log10 P-value") +
  ggtitle("Volcano Plot")

# ============================
# Combine all plots
# ============================
final_plot <- plot_grid(p_pca, p_heatmap, p_volcano, 
                        labels=c("A", "B", "C"), ncol=2)

# Save combined figure
ggsave("edgeR_results.pdf", final_plot, width=14, height=8)

cat("edgeR analysis complete! Results + PCA + Heatmap + Volcano combined in edgeR_results.png/pdf\n")

