# ============================
# DESeq2 with PCA, Heatmap, Volcano (Combined PDF)
# ============================

library(DESeq2)
library(ggplot2)
library(pheatmap)
library(ggrepel)
library(grid)
library(cowplot)

# Load count matrix
counts <- read.table("raw_reads.txt", header=TRUE, row.names=1, sep="\t", check.names=FALSE)

# Define samples and groups
samples <- c("SRR15276765","SRR15276766","SRR15276767",
             "SRR15276771","SRR15276773","SRR15276774")
# --- ADD THIS CODE BLOCK ---
# Clean up the long sample names to be short and readable
colnames(counts) <- gsub("../2_alignment/", "", colnames(counts))
colnames(counts) <- gsub("_sorted.bam", "", colnames(counts))
#counts <- counts[, samples] #changed this line for featurecounts
#automatically take all columns
samples <- colnames(counts)
condition <- factor(c("Control","Control","Control","Treatment","Treatment","Treatment"),
                    levels = c("Control","Treatment"))
coldata <- data.frame(row.names = samples, condition = condition)

# Run DESeq2
dds <- DESeqDataSetFromMatrix(countData = counts, colData = coldata, design = ~ condition)
dds <- DESeq(dds)
res <- results(dds)

# Save results
write.csv(as.data.frame(res), "DESeq2_results.csv")

# ============================
# PCA Plot
# ============================
rld <- rlog(dds)
pcaData <- plotPCA(rld, intgroup="condition", returnData=TRUE)
percentVar <- round(100 * attr(pcaData, "percentVar"))

p_pca <- ggplot(pcaData, aes(PC1, PC2, color=condition, label=name)) +
  geom_point(size=4) +
  geom_text_repel(show.legend=FALSE) +
  xlab(paste0("PC1: ", percentVar[1], "% variance")) +
  ylab(paste0("PC2: ", percentVar[2], "% variance")) +
  theme_classic() +
  ggtitle("PCA Plot")

# ============================
# Heatmap (PCC)
# ============================
norm_counts <- assay(rld)
pcc <- cor(norm_counts, method="pearson")

p_heatmap <- grid.grabExpr(
  pheatmap(pcc, annotation_col=coldata, main="Pearson Correlation Heatmap")
)

# ============================
# Volcano Plot
# ============================
res_df <- as.data.frame(res)
res_df$category <- "Not Sig"
res_df$category[res_df$pvalue < 0.05 & res_df$log2FoldChange >= 0.5] <- "Up"
res_df$category[res_df$pvalue < 0.05 & res_df$log2FoldChange <= -0.5] <- "Down"

p_volcano <- ggplot(res_df, aes(x=log2FoldChange, y=-log10(pvalue), color=category)) +
  geom_point(alpha=0.6) +
  scale_color_manual(values=c("Down"="blue", "Not Sig"="grey", "Up"="red")) +
  theme_classic() +
  xlab("log2 Fold Change") +
  ylab("-log10 p-value") +
  ggtitle("Volcano Plot")

# ============================
# Combine all plots
# ============================
final_plot <- plot_grid(p_pca, p_heatmap, p_volcano,
                        labels=c("A", "B", "C"), ncol=2)

# Save combined figure
ggsave("DESeq2_results.pdf", final_plot, width=14, height=8)

cat("DESeq2 analysis complete! Results + PCA + Heatmap + Volcano combined in DESeq2_results.pdf/png\n")

